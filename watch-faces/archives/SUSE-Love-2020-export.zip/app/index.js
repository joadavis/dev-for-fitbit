import { battery } from "power";
import clock from "clock";
import { display } from "display";
import document from "document";
import { me as appbit } from "appbit";
import { today as todayact } from "user-activity";
import { HeartRateSensor } from "heart-rate";
import { preferences } from "user-settings";
import * as util from "../common/utils";

// Update the clock every seconds
clock.granularity = "seconds";

// Get a handle on the <text> element
//const dateLabel = document.getElementById("dateLabel");
const dateweekday = document.getElementById("dateweekday");
const datemonthday = document.getElementById("datemonthday");
const hourLabel = document.getElementById("hourLabel");
const minLabel = document.getElementById("minLabel");
const battLabel = document.getElementById("batt-data");
const hrmData = document.getElementById("hrm-data");
const stepData = document.getElementById("step-data");
const texturedImg = document.getElementById("textured");
const tickcircle = document.getElementById("tick-circle");
const tickline = document.getElementById("tick-line");

const sensors = [];
//const days = ["su", "mo", "tu", "we", "th", "fr", "sa"];
const days = ["SU", "MO", "TU", "WE", "TH", "FR", "SA"];

if (HeartRateSensor) {
  const hrm = new HeartRateSensor({ frequency: 1 });
  hrm.addEventListener("reading", () => {
    //hrmData.text = JSON.stringify({
    //  heartRate: hrm.heartRate ? hrm.heartRate : 0
    //});
    hrmData.text = hrm.heartRate ? hrm.heartRate : 0;
  });
  sensors.push(hrm);
  hrm.start();
} else {
  // hide icon too?
  hrmData.style.display = "none";
}

display.addEventListener("change", () => {
  // Automatically stop all sensors when the screen is off to conserve battery
  display.on ? sensors.map(sensor => sensor.start()) : sensors.map(sensor => sensor.stop());
});


// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let todaynow = evt.date;
  let hours = todaynow.getHours();
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = util.monoDigits(hours % 12 || 12);
  } else {
    // 24h format
    //hours = util.zeroPad(hours);
    hours = util.monoDigits(hours);
  }
  let mins = util.monoDigits(todaynow.getMinutes());
  hourLabel.text = `${hours}`;
  minLabel.text = `${mins}`;
  
  battLabel.text = Math.floor(battery.chargeLevel) + "%";
  
  if (appbit.permissions.granted("access_activity")) {
    //console.log(`${today.adjusted.steps} Steps`);
    stepData.text = todayact.adjusted.steps;
  } else {
    stepData.style.display = "none";
  }
  
  let dayName = days[todaynow.getDay()];
  let date = util.monoDigits(todaynow.getDate());
  //dateLabel.text = dayName + date;
  dateweekday.text = dayName;
  datemonthday.text = date;
  
  if (todaynow.getMinutes() % 2) {
    //texturedImg.x = 0-todaynow.getSeconds();
    tickcircle.cx = (todaynow.getSeconds() * 5);
    tickline.x = (todaynow.getSeconds() * 5);
  } else {
    //texturedImg.x = todaynow.getSeconds()-60;
    tickcircle.cx = 300 - (todaynow.getSeconds() * 5);
    tickline.x = 300 - (todaynow.getSeconds() * 5);
  }
}
