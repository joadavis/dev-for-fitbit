// joadavis Feb 2020
// the intent is to have a fun way to practice Japanese time vocabulary
// the background image is based on Yosegi-zaiku

import { battery } from "power";
import clock from "clock";
import document from "document";
import { preferences } from "user-settings";
import * as util from "../common/utils";

// Update the clock every minute
clock.granularity = "minutes";

// Get a handle on the <text> element
const enghourLabel = document.getElementById("enghour");
const engminLabel = document.getElementById("engmin");
const engampmLabel = document.getElementById("engampm");
const jphourLabel = document.getElementById("jphour");
const jpampmLabel = document.getElementById("jpampm");
const romajiLabel = document.getElementById("romajihour");
const battLabel = document.getElementById("batt");

// Update the <text> element every tick with the current time
clock.ontick = (evt) => {
  let today = evt.date;
  let hours = today.getHours();
  let ampmText = "am";
  let jpampm = "午前";
  let romajiText = "gozen ";
  // not exactly...
  if (hours >= 12 && hours != 24) {
    ampmText = "pm";
    jpampm = "午後";
    romajiText = "gogo ";
  }
  // TODO: support for 24 hour time
  if (preferences.clockDisplay === "12h") {
    // 12h format
    hours = hours % 12 || 12;
  } else {
    // 24h format
    hours = util.zeroPad(hours);
  }
  let mins = util.zeroPad(today.getMinutes());
  
  // testing
  //hours = 23;
  //mins = 47;
  
  // update display text
  enghourLabel.text = `${hours}`;
  engminLabel.text = `:${mins}`;
  engampmLabel.text = ampmText;
  
  jpampmLabel.text = jpampm;
  romajiText = romajiText + util.convertToJpRomajiHour(hours) + util.convertToJpRomajiMinute(mins);

  romajiLabel.text = romajiText;
  
  jphourLabel.text = util.convertToJpHour(hours) + util.convertToJpMinute(mins);
  
  // battery level
  //console.log(Math.floor(battery.chargeLevel) + "%");
  if (battery.chargeLevel < 25) {
    battLabel.fill = "fb-red";
  } else {
    battLabel.fill = "fb-light-gray";
  }
  battLabel.text = Math.floor(battery.chargeLevel) + "%";
  
}
