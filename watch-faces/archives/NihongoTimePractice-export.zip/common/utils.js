// Add zero in front of numbers < 10
export function zeroPad(i) {
  if (i < 10) {
    i = "0" + i;
  }
  return i;
}

export function convertToJpHour(hour) {
  // Note it was easier/more efficient to have the ji and space included in each
  // TODO: double check the 24 hour phrases for 14,17,19
  let names = ['0じ ', 'いちじ ', 'にじ ', 'さんじ ',
               'よじ ','ごじ ','ろくじ ',
               'しちじ ','はちじ ','くじ ',
               'じゅうじ ','じゅういちじ ','じゅうにじ ',
               'じゅうさんじ ','じゅうよんじ ','じゅうごじ ',
               'じゅうろくじ ','じゅうななじ ','じゅうはちじ ',
               'じゅうきゅうじ ','にじゅうじ ','にじゅういちじ ',
               'にじゅうにじ ','にじゅうさんじ ','にじゅうよんじ '
              ];
  return names[hour];
}

export function convertToJpRomajiHour(hour) {
  // TODO: decide on correctness - nijuuyonji or nijuuyoji, juushichiji or juunanaji
  let names = ['0ji ', 'ichiji ', 'niji ', 'sanji ',
               'yoji ', 'goji ', 'rokuji ',
               'shichiji ', 'hachiji', 'kuji ',
               'juuji ', 'juuichiji ', 'juuniji ',
               'juusanji ', 'juuyonji ', 'juugoji ',
               'juurokuji ', 'juunanaji ', 'juuhachi ',
               'juukyuuji ', 'nijuuji ', 'nijuuichiji ',
               'nijuuniji ', 'nijuusanji ', 'nijuuyonji '
              ];
  return names[hour];
}


export function convertToJpMinute(min) {
  // split off the tens, they end with juu
  // then the ones with the special fun/pun
  let tensNames = ['', 'いちじゅう', 'にじゅう', 'さんじゅう',
                   'よじゅう','ごじゅう','ろくじゅう',
                   'しちじゅう','はちじゅう','くじゅう'
                  ];
  let onesNames = ['', 'いち', 'に', 'さん',
                   'よ','ご','ろく',
                   'なな','はち','く'
                  ];
  // special case
  if (min == 0) {
    return '';
  }
  return tensNames[Math.floor(min/10)] + onesNames[min%10] + '分';
}

export function convertToJpRomajiMinute(min) {
  // split off the tens, they end with juu
  // then the ones with the special fun/pun
  let tensNames = ['', 'juu', 'nijuu', 'sanjuu',
                   'yonjuu','gojuu','ろくじゅう',
                   'しちじゅう','はちじゅう','くじゅう'
                  ];
  let onesNames = ['ppun', 'ippun', 'nifun', 'sanpun',
                   'yonpun','gofun','roppun',
                   'nanafun','happun','kyuufun'
                  ];
  // special case
  if (min == 0) {
    return '';
  }
  return tensNames[Math.floor(min/10)] + onesNames[min%10];
}